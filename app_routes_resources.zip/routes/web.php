<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\InfrastrukturController;
use App\Http\Controllers\LaporanController;
use App\Http\Controllers\PengajuanController;
use App\Http\Controllers\MaintenanceController;
use App\Http\Controllers\AnggaranController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\MapController;
use App\Http\Controllers\ExportController;

Route::get('/', function () {
    if (auth()->check()) {
        return redirect('/dashboard');
    }
    return view('landing');
});

Route::middleware('auth')->group(function () {

    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

});

    // =============================================
    // INFRASTRUKTUR (Admin & Petugas: CRUD | Warga: Read only)
    // =============================================
    Route::middleware('auth')->group(function () {

    Route::resource('infrastruktur', InfrastrukturController::class)->except(['create','store','edit','update','destroy']);

    Route::middleware('role:admin,petugas')->group(function () {
        Route::resource('infrastruktur', InfrastrukturController::class)->only(['create','store','edit','update']);
    });

    Route::middleware('role:admin')->group(function () {
        Route::delete('/infrastruktur/{id}', [InfrastrukturController::class, 'destroy'])->name('infrastruktur.destroy');
    });

    // =============================================
    // LAPORAN KERUSAKAN
    // =============================================
    Route::get('/laporan-kerusakan', [LaporanController::class, 'index'])->name('laporan.index');
    Route::get('/laporan-kerusakan/create', [LaporanController::class, 'create'])->name('laporan.create');
    Route::post('/laporan-kerusakan', [LaporanController::class, 'store'])->name('laporan.store');

    Route::middleware('role:admin,petugas')->group(function () {
        Route::get('/laporan-kerusakan/{id}', [LaporanController::class, 'verifikasi'])->name('laporan.verifikasi');
        Route::put('/laporan-kerusakan/{id}/status', [LaporanController::class, 'updateStatus'])->name('laporan.updateStatus');
        Route::delete('/laporan-kerusakan/{id}', [LaporanController::class, 'destroy'])->name('laporan.destroy');
    });

    // =============================================
    // PENGAJUAN PEMBANGUNAN
    // =============================================
    Route::get('/pengajuan', [PengajuanController::class, 'index'])->name('pengajuan.index');
    Route::get('/pengajuan/create', [PengajuanController::class, 'create'])->name('pengajuan.create');
    Route::post('/pengajuan', [PengajuanController::class, 'store'])->name('pengajuan.store');
    Route::get('/pengajuan/{id}/edit', [PengajuanController::class, 'edit'])->name('pengajuan.edit');
    Route::put('/pengajuan/{id}', [PengajuanController::class, 'update'])->name('pengajuan.update');
    Route::delete('/pengajuan/{id}', [PengajuanController::class, 'destroy'])->name('pengajuan.destroy');
    Route::post('/pengajuan/store', [PengajuanController::class, 'store'])->name('pengajuan.store')->middleware('role:warga'); 
    // Update status pengajuan (Admin only)
    Route::put('/pengajuan/{id}/status', [PengajuanController::class, 'updateStatus'])
        ->name('pengajuan.updateStatus')
        ->middleware('role:admin');
    Route::resource('pengajuan', PengajuanController::class);
    
        
    // =============================================
    // MAINTENANCE (Admin & Petugas only)
    // =============================================
    Route::middleware('role:admin,petugas')->group(function () {
        Route::get('/maintenance', [MaintenanceController::class, 'index'])->name('maintenance.index');
        Route::get('/maintenance/create', [MaintenanceController::class, 'create'])->name('maintenance.create');
        Route::post('/maintenance', [MaintenanceController::class, 'store'])->name('maintenance.store');
        Route::get('/maintenance/{id}/edit', [MaintenanceController::class, 'edit'])->name('maintenance.edit');
        Route::put('/maintenance/{id}', [MaintenanceController::class, 'update'])->name('maintenance.update');
        Route::delete('/maintenance/{id}', [MaintenanceController::class, 'destroy'])->name('maintenance.destroy');
    });

    // =============================================
    // ANGGARAN (Admin only)
    // =============================================
    Route::middleware('role:admin')->group(function () {
        Route::get('/anggaran', [AnggaranController::class, 'index'])->name('anggaran.index');
        Route::get('/anggaran/create', [AnggaranController::class, 'create'])->name('anggaran.create');
        Route::post('/anggaran', [AnggaranController::class, 'store'])->name('anggaran.store');
        Route::get('/anggaran/{id}/edit', [AnggaranController::class, 'edit'])->name('anggaran.edit');
        Route::put('/anggaran/{id}', [AnggaranController::class, 'update'])->name('anggaran.update');
        Route::delete('/anggaran/{id}', [AnggaranController::class, 'destroy'])->name('anggaran.destroy');
    });

    // =============================================
    // PETA
    // =============================================
    Route::get('/peta', [MapController::class, 'index'])->name('peta.index');
    Route::get('/peta/data', [MapController::class, 'data'])->name('peta.data');

    // =============================================
    // EXPORT (Admin only)
    // =============================================
    Route::middleware('role:admin')->group(function () {
        Route::get('/export/pdf', [ExportController::class, 'pdf'])->name('export.pdf');
        Route::get('/export/excel', [ExportController::class, 'excel'])->name('export.excel'); // FIX: route excel ditambahkan
    });

    // =============================================
    // MANAJEMEN USER (Admin only)
    // =============================================
    Route::middleware('role:admin')->group(function () {
        Route::get('/users', [UserController::class, 'index'])->name('users.index');
        Route::get('/users/{id}/edit', [UserController::class, 'edit'])->name('users.edit');
        Route::put('/users/{id}', [UserController::class, 'update'])->name('users.update');
        Route::delete('/users/{id}', [UserController::class, 'destroy'])->name('users.destroy');
    });

    // Profile
    Route::get('/profile', [App\Http\Controllers\ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [App\Http\Controllers\ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [App\Http\Controllers\ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__ . '/auth.php';
